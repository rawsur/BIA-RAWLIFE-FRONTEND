import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-policy',
  templateUrl: './show-policy.component.html',
  styleUrls: ['./show-policy.component.scss']
})
export class ShowPolicyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
