import { Package } from './package';

describe('Package', () => {
  it('should create an instance', () => {
    expect(new Package()).toBeTruthy();
  });
});
